<?php
$con=mysqli_connect("localhost","root","","timetable");
?>
