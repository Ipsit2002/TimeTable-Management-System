<footer class="sticky-footer">
        <ul>
            <li><a>A Project by Ipsitneel Chaudhuri</a></li>
        </ul>
</footer>
